<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db.php';

function validateRegisterFields($name, $email, $password, $passwordConfirm) {
    if (empty($name) || !preg_match('/^[A-Za-zÀ-ÿ\s]+$/', $name)) {
        return ['success' => false, 'message' => 'El nombre debe contener solo letras.', 'field' => 'registerName'];
    }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['success' => false, 'message' => 'Ingresa un correo válido.', 'field' => 'registerEmail'];
    }
    if (empty($password) || !preg_match('/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/', $password)) {
        return ['success' => false, 'message' => 'La contraseña debe tener letras y números y al menos 6 caracteres.', 'field' => 'registerPassword'];
    }
    if ($password !== $passwordConfirm) {
        return ['success' => false, 'message' => 'Las contraseñas no coinciden.', 'field' => 'registerPasswordConfirm'];
    }
    return ['success' => true];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $passwordConfirm = $_POST['passwordConfirm'] ?? '';

    $validation = validateRegisterFields($name, $email, $password, $passwordConfirm);
    if (!$validation['success']) {
        echo json_encode($validation);
        exit;
    }

    $stmt = $conn->prepare("SELECT id FROM usuario WHERE correo_electronico = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'El correo electrónico ya está en uso.', 'field' => 'registerEmail']);
        exit;
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO usuario (nombre_de_usuario, correo_electronico, contrasena) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $hashedPassword);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Usuario registrado con éxito.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al registrar el usuario.']);
    }

    $stmt->close();
}
$conn->close();
?>