CREATE TABLE `usuario` (
  `fhecha_de_inicio_de_sesion` float[],
  `nombre_de_usuario` varchar(255),
  `correo_electronico` varchar[],
  `contraseña` varchar[],
  `id` int[]
);
