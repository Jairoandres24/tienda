<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Ingresa un correo válido.', 'field' => 'email']);
        exit;
    }

    if (empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Ingresa tu contraseña.', 'field' => 'password']);
        exit;
    }

    $stmt = $conn->prepare("SELECT contrasena FROM usuario WHERE correo_electronico = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Correo o contraseña incorrectos.', 'field' => 'password']);
        exit;
    }

    $user = $result->fetch_assoc();
    if (!password_verify($password, $user['contrasena'])) {
        echo json_encode(['success' => false, 'message' => 'Correo o contraseña incorrectos.', 'field' => 'password']);
        exit;
    }

    echo json_encode(['success' => true, 'message' => 'Inicio de sesión exitoso.']);
}
$conn->close();
?>