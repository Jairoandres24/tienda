const STORAGE_SESSION = 'loggedInUser';

function getLoggedInUser() {
    return sessionStorage.getItem(STORAGE_SESSION);
}

function setLoggedInUser(email) {
    sessionStorage.setItem(STORAGE_SESSION, email);
}

function clearLoggedInUser() {
    sessionStorage.removeItem(STORAGE_SESSION);
}

function setInvalid(input, message) {
    input.classList.add('is-invalid');
    const feedback = input.nextElementSibling;
    if (feedback) {
        feedback.textContent = message;
    }
}

function clearInvalid(input) {
    input.classList.remove('is-invalid');
    const feedback = input.nextElementSibling;
    if (feedback) {
        feedback.textContent = '';
    }
}

function isAlphaName(value) {
    return /^[A-Za-zÀ-ÿ\s]+$/.test(value);
}

function isEmailValid(value) {
    return /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(value);
}

function isPasswordValid(value) {
    return /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/.test(value);
}

function validateLoginFields(email, password) {
    let valid = true;
    if (!email) {
        setInvalid(document.getElementById('email'), 'Ingresa tu correo electrónico.');
        valid = false;
    } else if (!isEmailValid(email)) {
        setInvalid(document.getElementById('email'), 'El correo debe ser válido y puede contener letras y números.');
        valid = false;
    }
    if (!password) {
        setInvalid(document.getElementById('password'), 'Ingresa tu contraseña.');
        valid = false;
    } else if (!isPasswordValid(password)) {
        setInvalid(document.getElementById('password'), 'La contraseña debe tener letras y números y al menos 6 caracteres.');
        valid = false;
    }
    return valid;
}

function validateRegisterFields(name, email, password, passwordConfirm) {
    let valid = true;
    if (!name) {
        setInvalid(document.getElementById('registerName'), 'Ingresa tu nombre de usuario.');
        valid = false;
    } else if (!isAlphaName(name)) {
        setInvalid(document.getElementById('registerName'), 'El nombre debe contener solo letras.');
        valid = false;
    }
    if (!email) {
        setInvalid(document.getElementById('registerEmail'), 'Ingresa un correo electrónico.');
        valid = false;
    } else if (!isEmailValid(email)) {
        setInvalid(document.getElementById('registerEmail'), 'El correo debe ser válido y puede contener letras y números.');
        valid = false;
    }
    if (!password) {
        setInvalid(document.getElementById('registerPassword'), 'Ingresa una contraseña.');
        valid = false;
    } else if (!isPasswordValid(password)) {
        setInvalid(document.getElementById('registerPassword'), 'La contraseña debe tener letras y números y al menos 6 caracteres.');
        valid = false;
    }
    if (!passwordConfirm) {
        setInvalid(document.getElementById('registerPasswordConfirm'), 'Confirma tu contraseña.');
        valid = false;
    } else if (password !== passwordConfirm) {
        setInvalid(document.getElementById('registerPasswordConfirm'), 'Las contraseñas no coinciden.');
        valid = false;
    }
    return valid;
}

async function handleLogin(event) {
    event.preventDefault();

    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const email = emailInput.value.trim().toLowerCase();
    const password = passwordInput.value.trim();

    clearInvalid(emailInput);
    clearInvalid(passwordInput);

    if (!validateLoginFields(email, password)) {
        return;
    }

    try {
        const response = await fetch('base_de_datos/login.php', {
            method: 'POST',
            body: new URLSearchParams({ email, password })
        });
        const data = await response.json();

        if (!data.success) {
            const field = data.field || 'password';
            const input = field === 'email' ? emailInput : passwordInput;
            setInvalid(input, data.message || 'Error al iniciar sesión.');
            return;
        }

        setLoggedInUser(email);
        window.location.href = 'html/web.html';
    } catch (error) {
        setInvalid(passwordInput, 'No se pudo conectar con el servidor.');
    }
}

async function handleRegister(event) {
    event.preventDefault();

    const nameInput = document.getElementById('registerName');
    const emailInput = document.getElementById('registerEmail');
    const passwordInput = document.getElementById('registerPassword');
    const passwordConfirmInput = document.getElementById('registerPasswordConfirm');

    const name = nameInput.value.trim();
    const email = emailInput.value.trim().toLowerCase();
    const password = passwordInput.value.trim();
    const passwordConfirm = passwordConfirmInput.value.trim();

    clearInvalid(nameInput);
    clearInvalid(emailInput);
    clearInvalid(passwordInput);
    clearInvalid(passwordConfirmInput);

    if (!validateRegisterFields(name, email, password, passwordConfirm)) {
        return;
    }

    try {
        const response = await fetch('base_de_datos/registro.php', {
            method: 'POST',
            body: new URLSearchParams({ name, email, password, passwordConfirm })
        });
        const data = await response.json();

        if (!data.success) {
            const field = data.field || 'registerPassword';
            const fieldMap = {
                registerName: nameInput,
                registerEmail: emailInput,
                registerPassword: passwordInput,
                registerPasswordConfirm: passwordConfirmInput
            };
            setInvalid(fieldMap[field] || passwordInput, data.message || 'Error al registrarse.');
            return;
        }

        setLoggedInUser(email);
        window.location.href = 'html/web.html';
    } catch (error) {
        setInvalid(passwordInput, 'No se pudo conectar con el servidor.');
    }
}

function protectWebPage() {
    const loggedIn = getLoggedInUser();
    if (!loggedIn) {
        window.location.href = '../index.html';
    }
}

function logout() {
    clearLoggedInUser();
    window.location.href = '../index.html';
}

function redirectIfAuthenticated() {
    const loggedIn = getLoggedInUser();
    if (loggedIn) {
        window.location.href = 'html/web.html';
    }
}

function bindForms() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
}

function bindLogoutButton() {
    const logoutButton = document.getElementById('logoutButton');
    if (logoutButton) {
        logoutButton.addEventListener('click', logout);
    }
}

function setWelcomeText() {
    const welcomeText = document.getElementById('welcomeText');
    const email = getLoggedInUser();
    if (welcomeText) {
        welcomeText.textContent = email ? `Has iniciado sesión como ${email}.` : 'Has iniciado sesión correctamente.';
    }
}

function bindPage() {
    const page = window.location.pathname.split('/').pop().toLowerCase();

    if (page === 'web.html') {
        protectWebPage();
        bindLogoutButton();
        setWelcomeText();
    }

    if (page === 'index.html' || page === '') {
        redirectIfAuthenticated();
        bindForms();
    }
}

document.addEventListener('DOMContentLoaded', bindPage);

